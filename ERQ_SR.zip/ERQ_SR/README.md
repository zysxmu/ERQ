## Towards Accurate Post-Training Quantization of Vision Transformers via Error Reduction (ERQ)

Below are instructions for reproducing the classification results of ERQ. Note that this paper is **extended** from our previous ICML2024 paper: 

ERQ: Error Reduction for Post-Training Quantization of Vision Transformers (**spotlight**).


## Evaluation

- First, install all required package and download required pre-trained fp model according the instruction of README_SwinIR.md

- create a fold for save the fp output:

```bash
cd /path-to-code & mkdir fp_output
```

- Then, you can quantize and evaluate a single model using the following command:


```bash
python test_quant_expand.py [--task] [--scale] [--training_patch_size] [--model_path] [--opt] [--w_bit] [--a_bit] [--coe] [--bs]

optional arguments:
--task: Task name.
--scale: Resolution scale.
--training_patch_size: Fixed to 48.
--model_path: Path to pre-train model.
--opt: Path to configuration file.
--w_bit: Bit-precision of weights.
--a_bit: Bit-precision of activation.
--coe: Parameter of \lambda_1 and \lambda_2.
--bs: Number of calibration dataset.
```

- Example: Quantize *SwinIRx4* at W4/A4 precision:

```bash
CUDA_VISIBLE_DEVICES=0 python test_quant_expand.py --task classical_sr --scale 4 \
        --training_patch_size 48 \
        --model_path xxx/model_zoo/swinir/001_classicalSR_DIV2K_s48w8_SwinIR-M_x4.pth \
        --opt options/train_swinir_sr_classical.json --w_bits 4 --a_bits 4 --bs 8 \
        --coe 100
```


## Results

Below are the part of super-resolution results.
![img.png](img.png)

## Citation

This code and paper is extended from our previous ICML2024 paper: ERQ: Error Reduction for Post-Training Quantization of Vision Transformers (spotlight).

We highly appreciate it if you would please cite the following paper if our work is useful for your work:

```bash
@inproceedings{zhongerq,
  title={ERQ: Error Reduction for Post-Training Quantization of Vision Transformers},
  author={Zhong, Yunshan and Hu, Jiawei and Huang, You and Zhang, Yuxin and Ji, Rongrong},
  booktitle={Proceedings of the International Conference on Machine Learning (ICML)},
  year={2024}
}
```

## Acknowledge

Our code is heavily based on the code of RepQ-ViT. We highly appreciate their work.

```bash
@article{li2022repqvit,
  title={RepQ-ViT: Scale Reparameterization for Post-Training Quantization of Vision Transformers},
  author={Li, Zhikai and Xiao, Junrui and Yang, Lianwei and Gu, Qingyi},
  journal={arXiv preprint arXiv:2212.08254},
  year={2022}
}
```
