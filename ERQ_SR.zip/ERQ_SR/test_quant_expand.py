import argparse
import cv2
import glob
from collections import OrderedDict
import requests
import random
from torch.utils.data import DataLoader
import torch.nn.parameter as Parameter

from models.network_swinir import SwinIR as net
from utils import util_calculate_psnr_ssim as util
from quant import *
from utils_q import *
from data.select_dataset import define_Dataset
from utils_k import utils_option as option
import pickle

def main(json_path='options/train_msrresnet_psnr.json'):
    parser = argparse.ArgumentParser()
    parser.add_argument('--task', type=str, default='color_dn', help='classical_sr, lightweight_sr, real_sr, '
                                                                     'gray_dn, color_dn, jpeg_car, color_jpeg_car')
    parser.add_argument('--scale', type=int, default=1, help='scale factor: 1, 2, 3, 4, 8') # 1 for dn and jpeg car
    parser.add_argument('--noise', type=int, default=15, help='noise level: 15, 25, 50')
    parser.add_argument('--jpeg', type=int, default=40, help='scale factor: 10, 20, 30, 40')
    parser.add_argument('--training_patch_size', type=int, default=128, help='patch size used in training SwinIR. '
                                       'Just used to differentiate two different settings in Table 2 of the paper. '
                                       'Images are NOT tested patch by patch.')
    parser.add_argument('--large_model', action='store_true', help='use large model, only provided for real image sr')
    parser.add_argument('--model_path', type=str,
                        default='model_zoo/swinir/001_classicalSR_DIV2K_s48w8_SwinIR-M_x2.pth')
    parser.add_argument('--folder_lq', type=str, default=None, help='input low-quality test image folder')
    parser.add_argument('--folder_gt', type=str, default=None, help='input ground-truth test image folder')
    parser.add_argument('--tile', type=int, default=None, help='Tile size, None for no tile during testing (testing as a whole)')
    parser.add_argument('--tile_overlap', type=int, default=32, help='Overlapping of different tiles')
    parser.add_argument('--w_bits', default=4,
                        type=int, help='bit-precision of weights')
    parser.add_argument('--a_bits', default=4,
                        type=int, help='bit-precision of activation')
    parser.add_argument('--bs', default=1024,
                        type=int, help='batch sizes')
    parser.add_argument('--num_wks', default=16,
                        type=int, help='dataloader_num_workers')
    parser.add_argument('--opt', type=str, default=json_path, help='Path to option JSON file.')

    # brecq
    parser.add_argument('--iters_w', default=20000, type=int, help='number of iteration for adaround')
    parser.add_argument('--weight', default=0.01, type=float, help='weight of rounding cost vs the reconstruction loss.')
    parser.add_argument('--sym', action='store_true', help='symmetric reconstruction, not recommended')
    parser.add_argument('--b_start', default=20, type=int, help='temperature at the beginning of calibration')
    parser.add_argument('--b_end', default=2, type=int, help='temperature at the end of calibration')
    parser.add_argument('--warmup', default=0.2, type=float, help='in the warmup period no regularization is applied')
    parser.add_argument('--step', default=20, type=int, help='record snn output per step')

    parser.add_argument('--iters_a', default=5000, type=int, help='number of iteration for LSQ')
    parser.add_argument('--lr', default=4e-4, type=float, help='learning rate for LSQ')
    parser.add_argument('--p', default=2.4, type=float, help='L_p norm minimization for LSQ')
    
    # erq
    parser.add_argument('--coe', default=20000,
                        type=int, help='')

    args = parser.parse_args()

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    # set up model
    if os.path.exists(args.model_path):
        print(f'loading model from {args.model_path}')
    else:
        os.makedirs(os.path.dirname(args.model_path), exist_ok=True)
        url = 'https://github.com/JingyunLiang/SwinIR/releases/download/v0.0/{}'.format(os.path.basename(args.model_path))
        r = requests.get(url, allow_redirects=True)
        print(f'downloading model {args.model_path}')
        open(args.model_path, 'wb').write(r.content)
    
    # prepare for the opt
    opt = option.parse(args.opt, is_train=True)
    opt = option.dict_to_nonedict(opt)

    # seed
    seed = opt['datasets']['train']['manual_seed']
    if seed is None:
        seed = random.randint(1, 10000)
    print('Random seed: {}'.format(seed))

    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)

    model = define_model(args)
    model = build_model(model)
    model.eval()
    model = model.to(device)

    # prepare dataset 
    for phase, dataset_opt in opt['datasets'].items():
        if phase == 'train':
            train_set = define_Dataset(dataset_opt)
            train_loader = DataLoader(train_set,
                                          batch_size=args.bs,
                                          shuffle=dataset_opt['dataloader_shuffle'],
                                          num_workers=dataset_opt['dataloader_num_workers'],
                                          drop_last=True,
                                          pin_memory=True)
            break

    for i, train_data in enumerate(train_loader):
        calib_data = train_data['L']
        break
    calib_data = calib_data.to(device)

    wq_params = {'n_bits': args.w_bits, 'channel_wise': True}
    aq_params = {'n_bits': args.a_bits, 'channel_wise': False}

    q_model = quant_model(model, input_quant_params=aq_params, weight_quant_params=wq_params)
    q_model.to(device)
    q_model.eval()


    import time
    start_time = time.time()
    print('Performing initial quantization of Act ...')

    set_quant_state(q_model, input_quant=True, weight_quant=False)

    with torch.no_grad():
        _ = q_model(calib_data[:32])


    # computer W by fp-act and quant-act
    set_quant_state(q_model, input_quant=True, weight_quant=False)
    # repar first
    reparameterization(q_model, args)
    ## store fp output
    set_quant_state(q_model, input_quant=False, weight_quant=False)
    fp_folder_path = hook_fp_act(q_model, calib_data, args)


    set_quant_state(q_model, input_quant=True, weight_quant=False)
    replace_W(q_model, fp_folder_path, args)

    # Re-calibration
    set_quant_state(q_model, input_quant=True, weight_quant=True)
    with torch.no_grad():
        _ = q_model(calib_data)

    replace_W_afterquant_vector_twopart(q_model, fp_folder_path, args)

    #
    set_quant_state(q_model, input_quant=True, weight_quant=True)


    end_time = time.time()
    execution_time = end_time - start_time
    print("runing time of execution_time: ", execution_time, "s")

    # Validate the quantized model
    print("Acc of init act ...")
    args.folder_lq = '/media/ssd1/SR/benchmark/Set5/LR_bicubic/X' + str(args.scale)
    args.folder_gt = '/media/ssd1/SR/benchmark/Set5/HR'
    vali(args, q_model, device, store_pic=True)
    args.folder_lq = '/media/ssd1/SR/benchmark/Set14/LR_bicubic/X' + str(args.scale)
    args.folder_gt = '/media/ssd1/SR/benchmark/Set14/HR'
    vali(args, q_model, device, store_pic=True)
    args.folder_lq = '/media/ssd1/SR/benchmark/Urban100/LR_bicubic/X' + str(args.scale)
    args.folder_gt = '/media/ssd1/SR/benchmark/Urban100/HR'
    vali(args, q_model, device, store_pic=True)
    args.folder_lq = '/media/ssd1/SR/benchmark/B100/LR_bicubic/X' + str(args.scale)
    args.folder_gt = '/media/ssd1/SR/benchmark/B100/HR'
    vali(args, q_model, device, store_pic=True)
    print()
    print()


def define_model(args):
    # 001 classical image sr
    if args.task == 'classical_sr':
        model = net(upscale=args.scale, in_chans=3, img_size=args.training_patch_size, window_size=8,
                    img_range=1., depths=[6, 6, 6, 6, 6, 6], embed_dim=180, num_heads=[6, 6, 6, 6, 6, 6],
                    mlp_ratio=2, upsampler='pixelshuffle', resi_connection='1conv')
        param_key_g = 'params'

    # 002 lightweight image sr
    # use 'pixelshuffledirect' to save parameters
    elif args.task == 'lightweight_sr':
        model = net(upscale=args.scale, in_chans=3, img_size=64, window_size=8,
                    img_range=1., depths=[6, 6, 6, 6], embed_dim=60, num_heads=[6, 6, 6, 6],
                    mlp_ratio=2, upsampler='pixelshuffledirect', resi_connection='1conv')
        param_key_g = 'params'

    # 003 real-world image sr
    elif args.task == 'real_sr':
        if not args.large_model:
            # use 'nearest+conv' to avoid block artifacts
            model = net(upscale=args.scale, in_chans=3, img_size=64, window_size=8,
                        img_range=1., depths=[6, 6, 6, 6, 6, 6], embed_dim=180, num_heads=[6, 6, 6, 6, 6, 6],
                        mlp_ratio=2, upsampler='nearest+conv', resi_connection='1conv')
        else:
            # larger model size; use '3conv' to save parameters and memory; use ema for GAN training
            model = net(upscale=args.scale, in_chans=3, img_size=64, window_size=8,
                        img_range=1., depths=[6, 6, 6, 6, 6, 6, 6, 6, 6], embed_dim=240,
                        num_heads=[8, 8, 8, 8, 8, 8, 8, 8, 8],
                        mlp_ratio=2, upsampler='nearest+conv', resi_connection='3conv')
        param_key_g = 'params_ema'

    # 004 grayscale image denoising
    elif args.task == 'gray_dn':
        model = net(upscale=1, in_chans=1, img_size=128, window_size=8,
                    img_range=1., depths=[6, 6, 6, 6, 6, 6], embed_dim=180, num_heads=[6, 6, 6, 6, 6, 6],
                    mlp_ratio=2, upsampler='', resi_connection='1conv')
        param_key_g = 'params'

    # 005 color image denoising
    elif args.task == 'color_dn':
        model = net(upscale=1, in_chans=3, img_size=128, window_size=8,
                    img_range=1., depths=[6, 6, 6, 6, 6, 6], embed_dim=180, num_heads=[6, 6, 6, 6, 6, 6],
                    mlp_ratio=2, upsampler='', resi_connection='1conv')
        param_key_g = 'params'

    # 006 grayscale JPEG compression artifact reduction
    # use window_size=7 because JPEG encoding uses 8x8; use img_range=255 because it's sligtly better than 1
    elif args.task == 'jpeg_car':
        model = net(upscale=1, in_chans=1, img_size=126, window_size=7,
                    img_range=255., depths=[6, 6, 6, 6, 6, 6], embed_dim=180, num_heads=[6, 6, 6, 6, 6, 6],
                    mlp_ratio=2, upsampler='', resi_connection='1conv')
        param_key_g = 'params'

    # 006 color JPEG compression artifact reduction
    # use window_size=7 because JPEG encoding uses 8x8; use img_range=255 because it's sligtly better than 1
    elif args.task == 'color_jpeg_car':
        model = net(upscale=1, in_chans=3, img_size=126, window_size=7,
                    img_range=255., depths=[6, 6, 6, 6, 6, 6], embed_dim=180, num_heads=[6, 6, 6, 6, 6, 6],
                    mlp_ratio=2, upsampler='', resi_connection='1conv')
        param_key_g = 'params'

    pretrained_model = torch.load(args.model_path)
    model.load_state_dict(pretrained_model[param_key_g] if param_key_g in pretrained_model.keys() else pretrained_model, strict=True)

    return model


def setup(args):
    # 001 classical image sr/ 002 lightweight image sr
    if args.task in ['classical_sr', 'lightweight_sr']:
        save_dir = f'results/swinir_{args.task}_x{args.scale}'
        folder = args.folder_gt
        border = args.scale
        window_size = 8

    # 003 real-world image sr
    elif args.task in ['real_sr']:
        save_dir = f'results/swinir_{args.task}_x{args.scale}'
        if args.large_model:
            save_dir += '_large'
        folder = args.folder_lq
        border = 0
        window_size = 8

    # 004 grayscale image denoising/ 005 color image denoising
    elif args.task in ['gray_dn', 'color_dn']:
        save_dir = f'results/swinir_{args.task}_noise{args.noise}'
        folder = args.folder_gt
        border = 0
        window_size = 8

    # 006 JPEG compression artifact reduction
    elif args.task in ['jpeg_car', 'color_jpeg_car']:
        save_dir = f'results/swinir_{args.task}_jpeg{args.jpeg}'
        folder = args.folder_gt
        border = 0
        window_size = 7

    return folder, save_dir, border, window_size


def get_image_pair(args, path):
    (imgname, imgext) = os.path.splitext(os.path.basename(path))

    # 001 classical image sr/ 002 lightweight image sr (load lq-gt image pairs)
    if args.task in ['classical_sr', 'lightweight_sr']:
        # if 'Set5' in args.folder_lq:
        #     img_gt = cv2.imread(path, cv2.IMREAD_COLOR).astype(np.float32) / 255.
        #     img_lq = cv2.imread(f'{args.folder_lq}/{imgname}x{args.scale}{imgext}', cv2.IMREAD_COLOR).astype(
        #         np.float32) / 255.
        # else:
        img_gt = cv2.imread(path, cv2.IMREAD_COLOR).astype(np.float32) / 255.
        img_lq = cv2.imread(f'{args.folder_lq}/{imgname}x{args.scale}{imgext}', cv2.IMREAD_COLOR).astype(
            np.float32) / 255.

    # 003 real-world image sr (load lq image only)
    elif args.task in ['real_sr']:
        img_gt = None
        img_lq = cv2.imread(path, cv2.IMREAD_COLOR).astype(np.float32) / 255.

    # 004 grayscale image denoising (load gt image and generate lq image on-the-fly)
    elif args.task in ['gray_dn']:
        img_gt = cv2.imread(path, cv2.IMREAD_GRAYSCALE).astype(np.float32) / 255.
        np.random.seed(seed=0)
        img_lq = img_gt + np.random.normal(0, args.noise / 255., img_gt.shape)
        img_gt = np.expand_dims(img_gt, axis=2)
        img_lq = np.expand_dims(img_lq, axis=2)

    # 005 color image denoising (load gt image and generate lq image on-the-fly)
    elif args.task in ['color_dn']:
        img_gt = cv2.imread(path, cv2.IMREAD_COLOR).astype(np.float32) / 255.
        np.random.seed(seed=0)
        img_lq = img_gt + np.random.normal(0, args.noise / 255., img_gt.shape)

    # 006 grayscale JPEG compression artifact reduction (load gt image and generate lq image on-the-fly)
    elif args.task in ['jpeg_car']:
        img_gt = cv2.imread(path, cv2.IMREAD_UNCHANGED)
        if img_gt.ndim != 2:
            img_gt = util.bgr2ycbcr(img_gt, y_only=True)
        result, encimg = cv2.imencode('.jpg', img_gt, [int(cv2.IMWRITE_JPEG_QUALITY), args.jpeg])
        img_lq = cv2.imdecode(encimg, 0)
        img_gt = np.expand_dims(img_gt, axis=2).astype(np.float32) / 255.
        img_lq = np.expand_dims(img_lq, axis=2).astype(np.float32) / 255.

    # 006 JPEG compression artifact reduction (load gt image and generate lq image on-the-fly)
    elif args.task in ['color_jpeg_car']:
        img_gt = cv2.imread(path)
        result, encimg = cv2.imencode('.jpg', img_gt, [int(cv2.IMWRITE_JPEG_QUALITY), args.jpeg])
        img_lq = cv2.imdecode(encimg, 1)
        img_gt = img_gt.astype(np.float32)/ 255.
        img_lq = img_lq.astype(np.float32)/ 255.

    return imgname, img_lq, img_gt

def test(img_lq, model, args, window_size):
    if args.tile is None:
        # test the image as a whole
        output = model(img_lq)
    else:
        # test the image tile by tile
        b, c, h, w = img_lq.size()
        tile = min(args.tile, h, w)
        assert tile % window_size == 0, "tile size should be a multiple of window_size"
        tile_overlap = args.tile_overlap
        sf = args.scale

        stride = tile - tile_overlap
        h_idx_list = list(range(0, h-tile, stride)) + [h-tile]
        w_idx_list = list(range(0, w-tile, stride)) + [w-tile]
        E = torch.zeros(b, c, h*sf, w*sf).type_as(img_lq)
        W = torch.zeros_like(E)

        for h_idx in h_idx_list:
            for w_idx in w_idx_list:
                in_patch = img_lq[..., h_idx:h_idx+tile, w_idx:w_idx+tile]
                out_patch = model(in_patch)
                out_patch_mask = torch.ones_like(out_patch)

                E[..., h_idx*sf:(h_idx+tile)*sf, w_idx*sf:(w_idx+tile)*sf].add_(out_patch)
                W[..., h_idx*sf:(h_idx+tile)*sf, w_idx*sf:(w_idx+tile)*sf].add_(out_patch_mask)
        output = E.div_(W)

    return output

def vali(args, q_model, device, store_pic = False):
    folder, save_dir, border, window_size = setup(args)
    os.makedirs(save_dir, exist_ok=True)
    test_results = OrderedDict()
    test_results['psnr'] = []
    test_results['ssim'] = []
    test_results['psnr_y'] = []
    test_results['ssim_y'] = []
    test_results['psnrb'] = []
    test_results['psnrb_y'] = []
    psnr, ssim, psnr_y, ssim_y, psnrb, psnrb_y = 0, 0, 0, 0, 0, 0

    for idx, path in enumerate(sorted(glob.glob(os.path.join(folder, '*')))):
        # read image
        # import pdb;pdb.set_trace()
        imgname, img_lq, img_gt = get_image_pair(args, path)  # image to HWC-BGR, float32
        
        img_lq = np.transpose(img_lq if img_lq.shape[2] == 1 else img_lq[:, :, [2, 1, 0]], (2, 0, 1))  # HCW-BGR to CHW-RGB
        img_lq = torch.from_numpy(img_lq).float().unsqueeze(0).to(device)  # CHW-RGB to NCHW-RGB

        # inference
        with torch.no_grad():
            # pad input image to be a multiple of window_size
            _, _, h_old, w_old = img_lq.size()
            h_pad = (h_old // window_size + 1) * window_size - h_old
            w_pad = (w_old // window_size + 1) * window_size - w_old
            img_lq = torch.cat([img_lq, torch.flip(img_lq, [2])], 2)[:, :, :h_old + h_pad, :]
            img_lq = torch.cat([img_lq, torch.flip(img_lq, [3])], 3)[:, :, :, :w_old + w_pad]
            output = test(img_lq, q_model, args, window_size)
            output = output[..., :h_old * args.scale, :w_old * args.scale]

        # save image
        
        output = output.data.squeeze().float().cpu().clamp_(0, 1).numpy()
        if output.ndim == 3:
            output = np.transpose(output[[2, 1, 0], :, :], (1, 2, 0))  # CHW-RGB to HCW-BGR
        output = (output * 255.0).round().astype(np.uint8)  # float32 to uint8
        if store_pic:
            cv2.imwrite(f'{save_dir}/{imgname}_SwinIR.png', output)

        # evaluate psnr/ssim/psnr_b
        if img_gt is not None:
            img_gt = (img_gt * 255.0).round().astype(np.uint8)  # float32 to uint8
            img_gt = img_gt[:h_old * args.scale, :w_old * args.scale, ...]  # crop gt
            img_gt = np.squeeze(img_gt)

            psnr = util.calculate_psnr(output, img_gt, crop_border=border)
            ssim = util.calculate_ssim(output, img_gt, crop_border=border)
            test_results['psnr'].append(psnr)
            test_results['ssim'].append(ssim)
            if img_gt.ndim == 3:  # RGB image
                psnr_y = util.calculate_psnr(output, img_gt, crop_border=border, test_y_channel=True)
                ssim_y = util.calculate_ssim(output, img_gt, crop_border=border, test_y_channel=True)
                test_results['psnr_y'].append(psnr_y)
                test_results['ssim_y'].append(ssim_y)
            if args.task in ['jpeg_car', 'color_jpeg_car']:
                psnrb = util.calculate_psnrb(output, img_gt, crop_border=border, test_y_channel=False)
                test_results['psnrb'].append(psnrb)
                if args.task in ['color_jpeg_car']:
                    psnrb_y = util.calculate_psnrb(output, img_gt, crop_border=border, test_y_channel=True)
                    test_results['psnrb_y'].append(psnrb_y)
            print('Testing {:d} {:20s} - PSNR: {:.2f} dB; SSIM: {:.4f}; PSNRB: {:.2f} dB;'
                  'PSNR_Y: {:.2f} dB; SSIM_Y: {:.4f}; PSNRB_Y: {:.2f} dB.'.
                  format(idx, imgname, psnr, ssim, psnrb, psnr_y, ssim_y, psnrb_y))
        else:
            print('Testing {:d} {:20s}'.format(idx, imgname))

    # summarize psnr/ssim
    if img_gt is not None:
        ave_psnr = sum(test_results['psnr']) / len(test_results['psnr'])
        ave_ssim = sum(test_results['ssim']) / len(test_results['ssim'])
        print('\n{} \n-- Average PSNR/SSIM(RGB): {:.2f} dB; {:.4f}'.format(save_dir, ave_psnr, ave_ssim))
        if img_gt.ndim == 3:
            ave_psnr_y = sum(test_results['psnr_y']) / len(test_results['psnr_y'])
            ave_ssim_y = sum(test_results['ssim_y']) / len(test_results['ssim_y'])
            print('-- Average PSNR_Y/SSIM_Y: {:.2f} dB; {:.4f}'.format(ave_psnr_y, ave_ssim_y))
        if args.task in ['jpeg_car', 'color_jpeg_car']:
            ave_psnrb = sum(test_results['psnrb']) / len(test_results['psnrb'])
            print('-- Average PSNRB: {:.2f} dB'.format(ave_psnrb))
            if args.task in ['color_jpeg_car']:
                ave_psnrb_y = sum(test_results['psnrb_y']) / len(test_results['psnrb_y'])
                print('-- Average PSNRB_Y: {:.2f} dB'.format(ave_psnrb_y))

@torch.no_grad()
def reparameterization(q_model, args):
    # Scale reparameterization
    print('Performing scale reparameterization ...')
    with torch.no_grad():
        module_dict = {}
        q_model_slice = q_model.layers
        for name, module in q_model_slice.named_modules():
            module_dict[name] = module
            idx = name.rfind('.')
            if idx == -1:
                idx = 0
            father_name = name[:idx]
            if father_name in module_dict:
                father_module = module_dict[father_name]
            else:
                raise RuntimeError(f"father module {father_name} not found")
            # if 'norm1' in name or 'norm2' in name or 'norm' in name:
            if 'norm1' in name or 'norm2' in name:
                if 'norm1' in name:
                    next_module = father_module.attn.qkv
                elif 'norm2' in name:
                    next_module = father_module.mlp.fc1
                else:
                    next_module = father_module.reduction

                # next_module.is_repW.fill_(1)
                # next_module.two_part.fill_(1)

                act_delta = next_module.input_quantizer.delta.reshape(-1)
                act_zero_point = next_module.input_quantizer.zero_point.reshape(-1)
                act_min = -act_zero_point * act_delta

                target_delta = torch.mean(act_delta)
                target_zero_point = torch.mean(act_zero_point)
                target_min = -target_zero_point * target_delta

                r = act_delta / target_delta
                b = act_min / r - target_min

                module.weight.data = module.weight.data / r
                module.bias.data = module.bias.data / r - b

                next_module.weight.data = next_module.weight.data * r
                if next_module.bias is not None:
                    next_module.bias.data = next_module.bias.data + torch.mm(next_module.weight.data,
                                                                                b.reshape(-1, 1)).reshape(-1)
                else:
                    next_module.bias = Parameter(torch.Tensor(next_module.out_features))
                    next_module.bias.data = torch.mm(next_module.weight.data, b.reshape(-1, 1)).reshape(-1)

                next_module.input_quantizer.channel_wise = False
                next_module.input_quantizer.delta = Parameter(target_delta).contiguous()
                next_module.input_quantizer.zero_point = Parameter(target_zero_point).contiguous()
                next_module.weight_quantizer.inited.fill_(0)

@torch.no_grad()
def replace_W(q_model, folder_path,args):
    for n, m in q_model.named_modules():
        if isinstance(m, QuantLinear):
            with open(os.path.join(folder_path, n + 'store_input'), 'rb') as file:
                store_input = pickle.load(file)
            with open(os.path.join(folder_path, n + 'store_output'), 'rb') as file:
                store_output = pickle.load(file)

            print("complete collecting act...")
            fp_input = store_input[0]
            # if len(fp_input.shape) == 2:
            #     print("skip the last classification head!")
            #     return
            # num_of_inverse = 1e-1 * args.coe
            # print('num_of_inverse', num_of_inverse)
            if len(fp_input.shape) == 2:
                num_of_inverse = 0.1
                print('num_of_inverse', num_of_inverse)
            else:
                num_of_inverse = 1e-1 * args.coe
                print('num_of_inverse', num_of_inverse)


            fp_output_shape = store_output[0].shape
            fp_output_flat = store_output[0].cuda().reshape(-1, fp_output_shape[-1])
            quan_output = m.input_quantizer(store_input[0].cuda())
            del store_input



            w = m.weight.clone()

            if getattr(m, "bias") is not None:
                print('bias!')
                b = m.bias.clone()
                W_cat = torch.cat((w, b.unsqueeze(1)), dim=1).cuda()

                quan_output_flat = quan_output.reshape(-1, quan_output.shape[-1])
                quan_output_cat = torch.cat((quan_output_flat, torch.ones(quan_output_flat.shape[0], 1).cuda()),
                                            dim=1)

                A = quan_output_cat
                Y = fp_output_flat - (quan_output_cat @ W_cat.T)

                # beta, _ = torch.lstsq(Y, A.permute(1, 0) @ A + torch.eye(A.shape[1], device='cuda') * 1e-1)
                # beta, _ = torch.linalg.lstsq(Y, A.permute(1, 0) @ A + torch.eye(A.shape[1], device='cuda') * 1e-1)

                # beta = torch.inverse(A.permute(1,0) @ A ) @ A.permute(1,0) @ Y
                # beta = torch.inverse(A.permute(1,0) @ A + torch.rand(A.shape[1],A.shape[1],device=A.device)) @ A.permute(1,0) @ Y
                beta = torch.inverse(A.permute(1, 0) @ A
                                        + torch.eye(A.shape[1]).cuda() * num_of_inverse) @ A.permute(1, 0) @ Y

                new_W, new_b_0 = torch.split(beta, [beta.shape[0] - 1, 1], dim=0)  # split on the output channel
                new_b = new_b_0.squeeze()
                m.weight.data = new_W.T + w
                m.bias.data = new_b + b

                # judge whether the mse decend

                test1 = F.linear(quan_output, w) + b
                test2 = F.linear(quan_output, new_W.T + w) + b + new_b

                mse1 = lp_loss(fp_output_flat.view(fp_output_shape), test1)
                mse2 = lp_loss(fp_output_flat.view(fp_output_shape), test2)
                #
                # aa[n] = (mse1.item(), mse2.item())



                # print(f'test1(before change):{mse1}, test2(after change):{mse2}')
                # import pdb;pdb.set_trace()
                if mse1 > mse2:
                    print('-------succeed in change---------')
                else:
                    print('-------fail in change---------')

                del fp_output_flat, quan_output, w, b, W_cat, quan_output_flat, quan_output_cat, A, Y, \
                    beta, new_W, new_b_0, new_b, test1, test2, mse1, mse2
                torch.cuda.empty_cache()  # 清除未使用的缓存
            else:
                print('None bias!')
                W_cat = w.cuda()
                quan_output_flat = quan_output.reshape(-1, quan_output.shape[-1])
                quan_output_cat = quan_output_flat

                A = quan_output_cat
                Y = fp_output_flat - (quan_output_cat @ W_cat.T)

                # beta, _ = torch.lstsq(Y, A.permute(1, 0) @ A + torch.eye(A.shape[1], device='cuda') * 1e-1)
                # beta, _ = torch.linalg.lstsq(Y, A.permute(1, 0) @ A + torch.eye(A.shape[1], device='cuda') * 1e-1)

                # beta = torch.inverse(A.permute(1,0) @ A ) @ A.permute(1,0) @ Y
                # beta = torch.inverse(A.permute(1,0) @ A + torch.rand(A.shape[1],A.shape[1],device=A.device)) @ A.permute(1,0) @ Y
                beta = torch.inverse(A.permute(1, 0) @ A
                                        + torch.eye(A.shape[1]).cuda() * num_of_inverse) @ A.permute(1, 0) @ Y

                new_W = beta
                m.weight.data = new_W.T + w
                # judge whether the mse decend
                test1 = F.linear(quan_output, w)
                test2 = F.linear(quan_output, new_W.T + w)

                mse1 = lp_loss(fp_output_flat.view(fp_output_shape), test1)
                mse2 = lp_loss(fp_output_flat.view(fp_output_shape), test2)
                print(f'test1(before change):{mse1}, test2(after change):{mse2}')
                # import pdb;pdb.set_trace()
                if mse1 > mse2:
                    print('-------succeed in change---------')
                else:
                    print('-------fail in change---------')
                # 清理显存
                del fp_output_flat, quan_output, w, W_cat, quan_output_flat, quan_output_cat, A, Y, \
                    beta, new_W, test1, test2, mse1, mse2
                torch.cuda.empty_cache()  # 清除未使用的缓存
            print(f'complete computing for W in {n}')
            print()


        if isinstance(m, QuantConv2d):
            if 'first' in n:
                print('skip QuantConv2d!')
                continue
            with open(os.path.join(folder_path, n + 'store_input'), 'rb') as file:
                store_input = pickle.load(file)
            with open(os.path.join(folder_path, n + 'store_output'), 'rb') as file:
                store_output = pickle.load(file)

            print("complete collecting act...")
            quan_output = m.input_quantizer(store_input[0].cuda())

            # 卷积核参数
            kernel_size = m.weight.shape[2]
            stride = m.stride[0]
            padding = m.padding[0]
            quan_output_cols = im2col(quan_output, kernel_size, stride, padding)

            # 权重矩阵化
            weights_col = deepcopy(m.weight.reshape(m.weight.shape[0], -1).T)

            del store_input

            num_of_inverse = 1e-1 * args.coe
            print('num_of_inverse', num_of_inverse)

            with torch.no_grad():
                w = weights_col

                if getattr(m, "bias") is not None:
                    print('bias!')

                    b = m.bias.clone()
                    W_cat = torch.cat((w, b.unsqueeze(0)), dim=0).cuda()

                    quan_output_flat = quan_output_cols
                    quan_output_cat = torch.cat((quan_output_flat,
                                                    torch.ones(quan_output_flat.shape[0], 1).cuda()),
                                                dim=1)

                    A = quan_output_cat
                    tmp = (quan_output_cat @ W_cat)
                    fp_output_flat = store_output[0].cuda()
                    fp_output_flat = fp_output_flat.permute(0, 2, 3, 1).reshape(tmp.shape)
                    Y = fp_output_flat - tmp
                    beta = torch.inverse(A.permute(1, 0) @ A
                                            + torch.eye(A.shape[1]).cuda() * num_of_inverse) @ A.permute(1, 0) @ Y

                    new_W, new_b_0 = torch.split(beta, [beta.shape[0] - 1, 1], dim=0)  # split on the output channel
                    new_b = new_b_0.squeeze()

                    m.weight.data = (new_W + w).T.reshape(m.weight.shape)
                    m.bias.data = new_b + b

                    # judge whether the mse decend

                    test1 = F.conv2d(quan_output, w.T.reshape(m.weight.shape), b, stride, padding)
                    test2 = F.conv2d(quan_output, m.weight.data, m.bias.data, stride, padding)

                    mse1 = lp_loss(store_output[0].cuda(), test1)
                    mse2 = lp_loss(store_output[0].cuda(), test2)

                    if mse1 > mse2:
                        print('-------succeed in change---------')
                    else:
                        print('-------fail in change---------')

                    del fp_output_flat, quan_output, w, b, W_cat, quan_output_flat, quan_output_cat, A, Y, \
                        beta, new_W, new_b_0, new_b, test1, test2, mse1, mse2
                    torch.cuda.empty_cache()  # 清除未使用的缓存
                else:
                    print('None bias!')
                    W_cat = w.cuda()

                    quan_output_flat = quan_output_cols

                    A = quan_output_cat
                    tmp = (quan_output_cat @ W_cat)
                    fp_output_flat = store_output[0].cuda()
                    fp_output_flat = fp_output_flat.permute(0, 2, 3, 1).reshape(tmp.shape)
                    Y = fp_output_flat - tmp
                    beta = torch.inverse(A.permute(1, 0) @ A
                                            + torch.eye(A.shape[1]).cuda() * num_of_inverse) @ A.permute(1, 0) @ Y

                    new_W = beta

                    m.weight.data = (new_W + w).T.reshape(m.weight.shape)

                    # judge whether the mse decend

                    test1 = F.conv2d(quan_output, w.T.reshape(m.weight.shape), None, stride, padding)
                    test2 = F.conv2d(quan_output, m.weight.data, None, stride, padding)

                    mse1 = lp_loss(store_output[0].cuda(), test1)
                    mse2 = lp_loss(store_output[0].cuda(), test2)

                    if mse1 > mse2:
                        print('-------succeed in change---------')
                    else:
                        print('-------fail in change---------')
                    # 清理显存
                    del fp_output_flat, quan_output, w, W_cat, quan_output_flat, quan_output_cat, A, Y, \
                        beta, new_W, test1, test2, mse1, mse2
                    torch.cuda.empty_cache()  # 清除未使用的缓存
            print(f'complete computing for W in {n}')
            print()

    return

@torch.no_grad()
def replace_W_afterquant_vector_twopart(q_model, folder_path, args):

    # aa = {}
    for n, m in q_model.named_modules():
        if isinstance(m, QuantLinear):
            with open(os.path.join(folder_path, n + 'store_input'), 'rb') as file:
                store_input = pickle.load(file)
            with open(os.path.join(folder_path, n + 'store_output'), 'rb') as file:
                store_output = pickle.load(file)

            print("complete collecting act...")
            fp_input = store_input[0]
            # if len(fp_input.shape) == 2:
            #     print("skip the last classification head!")
            #     return
            # num_of_inverse = 1e-1 * args.coe
            # print('num_of_inverse', num_of_inverse)
            if len(fp_input.shape) == 2:
                num_of_inverse = 0.1
                print('num_of_inverse', num_of_inverse)
            else:
                num_of_inverse = 1e-1 * args.coe
                print('num_of_inverse', num_of_inverse)

            quan_output = m.input_quantizer(store_input[0].cuda())
            # del store_input

            num_of_inverse = 1e-1 * args.coe
            print('num_of_inverse', num_of_inverse)

            if getattr(m, "bias") is not None:
                print('bias!')
                w = m.weight.clone()
                b = m.bias.clone()

                print(f'redistribute W, there are {w.shape[0]} output channel of layer {n}')

                quan_output_flat = quan_output.reshape(-1, quan_output.shape[-1])
                quan_output_flat = torch.cat(
                    (quan_output_flat, torch.ones((quan_output_flat.shape[0], 1)).cuda()), dim=1)

                current = torch.cat((w, b.clone().unsqueeze(1)), dim=1).detach().clone().cuda()
                mask = torch.ones_like(current[0]).bool()
                while torch.sum(mask) > 1:

                    number_of_quant = torch.sum(mask) // 2
                    number_of_adjust = torch.sum(mask) - number_of_quant

                    x_dequant_floor = m.weight_quantizer(current, 'floor')
                    w_error_floor = x_dequant_floor - current
                    w_error_floor[:, -1] = 0

                    x_dequant_ceil = m.weight_quantizer(current, 'ceil')
                    w_error_ceil = x_dequant_ceil - current
                    w_error_ceil[:, -1] = 0

                    x_dequant = m.weight_quantizer(current, 'round')
                    w_error = x_dequant - current
                    w_error[:, -1] = 0

                    outlier_indices = torch.arange(0+torch.sum(~mask), number_of_quant+torch.sum(~mask))

                    # if args.model == 'swin_small' or args.model == 'swin_tiny':
                    #     B = 500
                    # elif args.model == 'swin_base':
                    #     B = 100
                    # else:
                    #     B = 500
                    B = 50

                    ###
                    if ('.mlp.fc1' in n or '.attn.qkv' in n):
                    # if False:
                    # if True:
                        means = torch.mean(quan_output_flat[:, outlier_indices], dim=0)
                        covs = torch.cov(quan_output_flat[:, outlier_indices].T)
                        coes = means.unsqueeze(0).T @ means.unsqueeze(0) + covs

                        groups = math.ceil(len(current) / B)
                        for g in range(groups):

                            a = np.arange(g * B, min((g + 1) * B, len(current)))
                            current_outputs = torch.tensor(a).cuda()


                            sub_delta1 = w_error.clone()[current_outputs][:, outlier_indices]
                            sub_delta_floor = w_error_floor[current_outputs][:, outlier_indices]
                            sub_delta_ceil = w_error_ceil[current_outputs][:, outlier_indices]

                            fail_dim = torch.zeros(len(sub_delta1)).bool()
                            count = 0
                            while count < 100 and torch.sum(~fail_dim) > 0:
                                count += 1

                                gradient = (2 * coes @ sub_delta1.T).T
                                same_sign = (sub_delta1 * gradient > 0)
                                gradient[~same_sign] = 0  # find these para that need to be change sign
                                gradient[:, ~mask[outlier_indices]] = 0
                                '''
                                tmp = sub_delta1 - gradient
                                distance_to_ceil = torch.abs(tmp - sub_delta_ceil)
                                distance_to_floor = torch.abs(tmp - sub_delta_floor)
                                v = torch.where(distance_to_ceil <= distance_to_floor, sub_delta_ceil, sub_delta_floor)
                                cur_min = sub_delta1.unsqueeze(1) @ coes @ sub_delta1.unsqueeze(2)
                                cur_min = cur_min.squeeze()
                                cur_min_v = v.unsqueeze(1) @ coes @ v.unsqueeze(2)
                                cur_min_v = cur_min_v.squeeze()
                                fail_dim = cur_min_v > cur_min
                                sub_delta1[~fail_dim] = v[~fail_dim]
                                '''
                                number_of_nonzero_gradi = torch.sum(gradient != 0, dim=1)
                                number_of_flip = torch.minimum(number_of_nonzero_gradi, torch.tensor(1))
                                _, max_diff_indexs = torch.topk(abs(gradient), k=int(torch.max(number_of_flip).item()), dim=1)

                                # number_of_flip = torch.round(torch.min(number_of_nonzero_gradi)*0.1)
                                # _, max_diff_indexs = torch.topk(abs(gradient), k=int(number_of_flip.item()), dim=1)

                                v = torch.gather(sub_delta1, 1, max_diff_indexs) - torch.gather(gradient, 1, max_diff_indexs)
                                ceils = torch.gather(sub_delta_ceil, 1, max_diff_indexs)
                                floors = torch.gather(sub_delta_floor, 1, max_diff_indexs)
                                distance_to_ceil = torch.abs(v - ceils)
                                distance_to_floor = torch.abs(v - floors)
                                v = torch.where(distance_to_ceil <= distance_to_floor, ceils, floors)

                                cur_min = (sub_delta1.unsqueeze(1) @ coes @ sub_delta1.unsqueeze(2)).squeeze()
                                tmp = torch.gather(sub_delta1, 1, max_diff_indexs).clone()
                                sub_delta1.scatter_(1, max_diff_indexs, v)

                                cur_min_v = (sub_delta1.unsqueeze(1) @ coes @ sub_delta1.unsqueeze(2)).squeeze()

                                fail_dim = cur_min_v > cur_min

                                temp = sub_delta1[fail_dim].clone()
                                temp.scatter_(1, max_diff_indexs[fail_dim], tmp[fail_dim])
                                sub_delta1[fail_dim] = temp

                            # if 'blocks.3.mlp.fc1' in n:
                            # # if 'blocks.3.attn.qkv' in n:
                            #     X = quan_output_flat[:, outlier_indices]
                            #     aa = X@sub_delta1.T
                            #     aa = torch.sum(aa ** 2, dim=0)
                            #     aa = aa.detach().cpu().numpy()
                            #
                            #     bb = X@w_error[current_outputs.unsqueeze(1), outlier_indices].T
                            #     bb = torch.sum(bb ** 2, dim=0)
                            #     bb = bb.detach().cpu().numpy()
                            #
                            #     with open(os.path.join(args.model + n + 'after_adjusted'), 'wb') as file:
                            #         pickle.dump(aa, file)
                            #     m.store_input.clear()
                            #     with open(os.path.join(args.model + n + 'before_adjusted'), 'wb') as file:
                            #         pickle.dump(bb, file)
                            #     import IPython
                            #     IPython.embed()
                            w_error[current_outputs.unsqueeze(1), outlier_indices] = sub_delta1
                    ###


                    mask[outlier_indices] = False
                    remaining_indices = torch.nonzero(mask).squeeze()
                    non_outliers_indices = remaining_indices
                    groups = math.ceil(len(current) / B)

                    for g in range(groups):
                        current_outputs = torch.arange(g * B, min((g + 1) * B, len(current))).cuda()

                        w1 = current[current_outputs][:, outlier_indices]
                        w2 = current[current_outputs][:, non_outliers_indices]

                        I1 = quan_output_flat[:, outlier_indices]
                        I2 = quan_output_flat[:, non_outliers_indices]
                        delta1 = w_error[current_outputs][:, outlier_indices]
                        delta2 = -torch.inverse(
                            I2.T @ I2 + num_of_inverse * torch.eye(number_of_adjust).cuda()) @ (
                                            I2.T @ I1) @ delta1.T
                        w2 += delta2.T

                        if len(w2.shape) == 1:
                            w2 = w2.unsqueeze(1)

                        current[current_outputs.unsqueeze(1), outlier_indices] = w1 + delta1
                        current[current_outputs.unsqueeze(1), non_outliers_indices] = w2


                new_w, new_b = torch.split(current, [current.shape[1] - 1, 1], dim=1)

                target = store_output[0].cuda()
                test1 = F.linear(quan_output, new_w) + new_b.squeeze()
                mse1 = lp_loss(target, test1)
                # aa[n] = (mse1.item())

                w.copy_(new_w)
                b.copy_(new_b.squeeze())

                m.weight.data = w
                m.bias.data = b
                m.set_quant_state(True, False)
                torch.cuda.empty_cache()

            else:
                w = m.weight.clone()
                print('None bias!')
                for i, _ in enumerate(range(w.shape[0])):
                    print(f'redistribute W of {i}/{w.shape[0]} output channel of layer {n}')

                    quan_output_flat = quan_output.reshape(-1, quan_output.shape[-1])
                    current = w[i, :].clone().detach().cuda()

                    mask = torch.ones_like(current).bool()

                    while torch.sum(mask) > 1:
                        number_of_quant = torch.sum(mask) // 2
                        number_of_adjust = torch.sum(mask) - number_of_quant

                        x_dequant_floor = m.weight_quantizer(current, 'floor', i)
                        w_error_floor = x_dequant_floor - current

                        x_dequant_ceil = m.weight_quantizer(current, 'ceil', i)
                        w_error_ceil = x_dequant_ceil - current

                        x_dequant = m.weight_quantizer(current, 'round', i)
                        w_error = x_dequant - current

                        w_error[~mask] += torch.inf
                        w_error[-1] += torch.inf
                        _, outlier_indices = torch.topk(-torch.abs(w_error), number_of_quant)

                        if ('.mlp.fc1' in n or '.attn.qkv' in n):
                            # if False:
                            means = torch.mean(quan_output_flat[:, outlier_indices], dim=0)
                            covs = torch.cov(quan_output_flat[:, outlier_indices].T)
                            coes = means.unsqueeze(0).T @ means.unsqueeze(0) + covs

                            sub_delta1 = w_error.clone()[outlier_indices]
                            # sub_delta1 = sub_delta1[:-1]
                            sub_delta_floor = w_error_floor[:-1][outlier_indices]
                            sub_delta_ceil = w_error_ceil[:-1][outlier_indices]
                            sub_indicators = (sub_delta1 == sub_delta_floor).int()

                            count = 0
                            while count < 100:
                                count += 1
                                gradient = 2 * coes @ sub_delta1
                                same_sign = (sub_delta1 * gradient > 0)
                                gradient[~same_sign] = 0  # find these para that need to be change sign
                                gradient[~mask[outlier_indices]] = 0

                                number_of_nonzero_gradi = torch.sum(gradient != 0)
                                number_of_flip = min(number_of_nonzero_gradi, 1)
                                _, max_diff_indexs = torch.topk(abs(gradient), number_of_flip)

                                v = sub_delta1[max_diff_indexs] - gradient[max_diff_indexs]
                                distance_to_ceil = torch.abs(v - sub_delta_ceil[max_diff_indexs])
                                distance_to_floor = torch.abs(v - sub_delta_floor[max_diff_indexs])
                                v = torch.where(distance_to_ceil <= distance_to_floor,
                                                sub_delta_ceil[max_diff_indexs], sub_delta_floor[max_diff_indexs])
                                # a = sub_delta1.clone()
                                # a[max_diff_indexs] = v
                                cur_min = sub_delta1.T @ coes @ sub_delta1
                                tmp = sub_delta1[max_diff_indexs].clone()
                                sub_delta1[max_diff_indexs] = v
                                cur_min_v = sub_delta1.T @ coes @ sub_delta1
                                if cur_min_v >= cur_min:
                                    sub_delta1[max_diff_indexs] = tmp
                                    break
                                w_error[:-1] = sub_delta1

                        mask[outlier_indices] = False
                        remaining_indices = torch.nonzero(mask).squeeze()
                        non_outliers_indices = remaining_indices

                        w1 = current[outlier_indices]
                        w2 = current[non_outliers_indices]

                        I1 = quan_output_flat[:, outlier_indices]
                        I2 = quan_output_flat[:, non_outliers_indices]
                        delta1 = w_error[outlier_indices]
                        delta2 = -torch.inverse(
                            I2.T @ I2 + num_of_inverse * torch.eye(number_of_adjust).cuda()) @ (
                                            I2.T @ I1) @ delta1
                        w2 += delta2
                        current[outlier_indices] = w1 + delta1
                        current[non_outliers_indices] = w2


                    x_dequant = m.weight_quantizer(current, 'round', i)
                    remaining_indices = torch.nonzero(mask).squeeze()
                    current[remaining_indices] = x_dequant[remaining_indices]

                    new_w = current
                    print('max w[i, :]', torch.max(w[i, :]), 'min w[i, :]', torch.min(w[i, :]),
                            'max new_w', torch.max(new_w), 'min new_w', torch.min(new_w), )
                    w[i, :].copy_(new_w)



                m.weight.data = w
                m.set_quant_state(True, False)
                torch.cuda.empty_cache()
            print(f'complete computing for W in {n}')
            print()

        if isinstance(m, QuantConv2d):
            with open(os.path.join(folder_path, n + 'store_input'), 'rb') as file:
                store_input = pickle.load(file)
            with open(os.path.join(folder_path, n + 'store_output'), 'rb') as file:
                store_output = pickle.load(file)

            print("complete collecting act...")

            if hasattr(m, 'input_quantizer'):
                quan_output = m.input_quantizer(store_input[0].cuda())
            else:
                quan_output = store_input[0].cuda()

            # 卷积核参数
            kernel_size = m.weight.shape[2]
            stride = m.stride[0]
            padding = m.padding[0]
            quan_output_cols = im2col(quan_output, kernel_size, stride, padding)

            # 权重矩阵化
            weights_col = deepcopy(m.weight.reshape(m.weight.shape[0], -1).T)

            del store_input

            num_of_inverse = 1e-1 * args.coe * 10
            print('num_of_inverse', num_of_inverse)

            # if False:
            if getattr(m, "bias") is not None:

                print('bias!')
                w = weights_col
                b = m.bias.clone()
                print(f'redistribute W, there are {w.shape[0]} output channel of layer {n}')
                quan_output_flat = quan_output_cols
                quan_output_flat = torch.cat((quan_output_flat,
                                                torch.ones(quan_output_flat.shape[0], 1).cuda()),
                                            dim=1)

                current = torch.cat((w, b.unsqueeze(0)), dim=0).detach().clone().cuda()
                # current = current.unsqueeze(0).unsqueeze(0)
                current = current.T
                mask = torch.ones_like(current[0]).bool()

                while torch.sum(mask) > 1:

                    number_of_quant = torch.sum(mask) // 2
                    number_of_adjust = torch.sum(mask) - number_of_quant

                    current = current.unsqueeze(2).unsqueeze(2)
                    x_dequant = m.weight_quantizer(current, 'round')
                    w_error = x_dequant - current
                    w_error[:, -1] = 0
                    w_error = w_error.squeeze()
                    current = current.squeeze()

                    outlier_indices = torch.arange(0+torch.sum(~mask), number_of_quant+torch.sum(~mask))

                    # if args.model == 'swin_small' or args.model == 'swin_tiny':
                    #     B = 500
                    # elif args.model == 'swin_base':
                    #     B = 100
                    # else:
                    #     B = 500
                    B = 500

                    mask[outlier_indices] = False
                    remaining_indices = torch.nonzero(mask).squeeze()
                    non_outliers_indices = remaining_indices
                    groups = math.ceil(len(current) / B)

                    for g in range(groups):

                        current_outputs = torch.arange(g * B, min((g + 1) * B, len(current))).cuda()

                        w1 = current[current_outputs][:, outlier_indices]
                        w2 = current[current_outputs][:, non_outliers_indices]

                        I1 = quan_output_flat[:, outlier_indices]
                        I2 = quan_output_flat[:, non_outliers_indices]
                        delta1 = w_error[current_outputs][:, outlier_indices]
                        delta2 = -torch.inverse(
                            I2.T @ I2 + num_of_inverse * torch.eye(number_of_adjust).cuda()) @ (
                                            I2.T @ I1) @ delta1.T
                        w2 += delta2.T

                        if len(w2.shape) == 1:
                            w2 = w2.unsqueeze(1)

                        current[current_outputs.unsqueeze(1), outlier_indices] = w1 + delta1
                        current[current_outputs.unsqueeze(1), non_outliers_indices] = w2

                new_w, new_b = torch.split(current, [current.shape[1] - 1, 1], dim=1)
                new_b = new_b.squeeze()

                test1 = F.conv2d(quan_output, new_w.reshape(m.weight.shape), new_b, stride, padding)
                test2 = F.conv2d(quan_output, m.weight_quantizer(m.weight.data), m.bias.data, stride, padding)
                mse1 = lp_loss(store_output[0].cuda(), test1)
                mse2 = lp_loss(store_output[0].cuda(), test2)
                print('##')
                print(mse1, mse2)
                print('##')

                m.weight.data = new_w.reshape(m.weight.shape)
                m.bias.data = new_b

                m.set_quant_state(True, False)
                torch.cuda.empty_cache()

            else:
                w = m.weight.clone()
                print('None bias!')
                for i, _ in enumerate(range(w.shape[0])):
                    print(f'redistribute W of {i}/{w.shape[0]} output channel of layer {n}')

                    quan_output_flat = quan_output_cols
                    current = w[i, :].clone().detach().cuda()
                    current = current.reshape(-1)
                    mask = torch.ones_like(current).bool()
                    mask = mask.reshape(-1)

                    while torch.sum(mask) > 1:

                        number_of_quant = torch.sum(mask) // 2
                        number_of_adjust = torch.sum(mask) - number_of_quant

                        x_dequant = m.weight_quantizer(current, 'round', i)
                        w_error = x_dequant - current
                        w_error = w_error.reshape(-1)

                        w_error[~mask] += torch.inf
                        w_error[-1] += torch.inf
                        _, outlier_indices = torch.topk(-torch.abs(w_error), number_of_quant)


                        mask[outlier_indices] = False
                        remaining_indices = torch.nonzero(mask).squeeze()
                        non_outliers_indices = remaining_indices

                        w1 = current[outlier_indices]
                        w2 = current[non_outliers_indices]

                        I1 = quan_output_flat[:, outlier_indices]
                        I2 = quan_output_flat[:, non_outliers_indices]
                        delta1 = w_error[outlier_indices]

                        delta2 = -torch.inverse(
                            I2.T @ I2 + num_of_inverse * torch.eye(number_of_adjust).cuda()) @ (
                                            I2.T @ I1) @ delta1
                        w2 += delta2
                        current[outlier_indices] = w1 + delta1
                        current[non_outliers_indices] = w2

                    x_dequant = m.weight_quantizer(current, 'round', i)
                    x_dequant = x_dequant.reshape(-1)
                    remaining_indices = torch.nonzero(mask).squeeze()
                    current[remaining_indices] = x_dequant[remaining_indices]

                    new_w = current
                    print('max w[i, :]', torch.max(w[i, :]), 'min w[i, :]', torch.min(w[i, :]),
                            'max new_w', torch.max(new_w), 'min new_w', torch.min(new_w), )
                    w[i, :].copy_(new_w.reshape(w[i, :].shape))

                m.weight.data = w
                m.set_quant_state(True, False)

                torch.cuda.empty_cache()
            print(f'complete computing for W in {n}')
            print()

    return                  

def hook_fp_act(q_model, calib_data, args):
    '''
    Args:
        q_model: the quantization model
        cali_data: calibration data
    '''
    # register hook
    hooks = []
    for n, m in q_model.named_modules():
        if isinstance(m, QuantLinear):
            hooks.append(m.register_forward_hook(myhook))
        if isinstance(m, QuantConv2d):
            hooks.append(m.register_forward_hook(myhook))
    # input
    with torch.no_grad():
        _ = q_model(calib_data)

    # remove hook
    for h in hooks:
        h.remove()

    folder_path = f"fp_output/swinir-calib{args.bs}-W{args.w_bits}A{args.a_bits}"
    os.makedirs(folder_path, exist_ok=True)
    for n, m in q_model.named_modules():
        if isinstance(m, QuantLinear):
            with open(os.path.join(folder_path, n + 'store_input'), 'wb') as file:
                pickle.dump(m.store_input, file)
            m.store_input.clear()
            with open(os.path.join(folder_path, n + 'store_output'), 'wb') as file:
                pickle.dump(m.store_output, file)
            m.store_output.clear()
        if isinstance(m, QuantConv2d):
            with open(os.path.join(folder_path, n + 'store_input'), 'wb') as file:
                pickle.dump(m.store_input, file)
            m.store_input.clear()
            with open(os.path.join(folder_path, n + 'store_output'), 'wb') as file:
                pickle.dump(m.store_output, file)
            m.store_output.clear()

    print("complete collecting fp act...")
    return folder_path

def myhook(module, input, output):
    if module.store_input == None:
        module.store_input = []
        module.store_output = []
    module.store_input.append(input[0].cpu().detach())
    module.store_output.append(output.cpu().detach())

def lp_loss(pred, tgt, p=2.0, reduction='none'):
    """
    loss function measured in L_p Norm
    """
    return (pred - tgt).abs().pow(p).sum()
    if reduction == 'none':
        return (pred - tgt).abs().pow(p).sum(1).mean()
    else:
        return (pred - tgt).abs().pow(p).mean()

def im2col(input_data, kernel_size, stride, padding):
    # 添加padding
    input_padded = F.pad(input_data, (padding, padding, padding, padding))
    # 获取输入数据的维度
    batch_size, channels, height, width = input_padded.shape

    # 输出的高度和宽度
    out_height = (height - kernel_size) // stride + 1
    out_width = (width - kernel_size) // stride + 1

    # 展开操作
    cols = torch.zeros(batch_size, channels, kernel_size, kernel_size, out_height, out_width, device=input_data.device)

    for y in range(kernel_size):
        y_max = y + stride*out_height
        for x in range(kernel_size):
            x_max = x + stride*out_width
            cols[:, :, y, x, :, :] = input_padded[:, :, y:y_max:stride, x:x_max:stride]

    cols = cols.permute(0, 4, 5, 1, 2, 3).reshape(batch_size*out_height*out_width, -1)
    return cols
    
if __name__ == '__main__':
    main()
